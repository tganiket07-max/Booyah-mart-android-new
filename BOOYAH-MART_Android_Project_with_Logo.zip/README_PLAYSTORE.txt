BOOYAH-MART Android wrapper
===========================

App name: BOOYAH-MART
Application ID: com.booyahmart.app

This project wraps the current BOOYAH-MART HTML in an Android WebView.

Before Play Store release:
1. Replace the placeholder app icon with the user's supplied icon in Android mipmap resources.
2. Add a real backend/database for multi-user data and secure admin authentication.
3. Add final Terms of Service and Privacy Policy URLs/pages.
4. Test UGC reporting/blocking and payment flows.
5. Build a signed Android App Bundle (.aab) with Android Studio/Gradle.
6. Complete Google Play Console testing, Data Safety and other required declarations.

The current HTML is in app/src/main/assets/index.html.
